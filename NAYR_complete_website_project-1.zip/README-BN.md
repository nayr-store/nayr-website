# NAYR অনলাইন শপ — সেটআপ নির্দেশিকা

এটি একটি responsive storefront + Admin Dashboard-সহ Node.js ওয়েব অ্যাপ। এতে SQLite ডেটাবেস, পণ্য ব্যবস্থাপনা, ছবি আপলোড, অর্ডার সংরক্ষণ, অর্ডার স্ট্যাটাস, শপ সেটিংস ও Admin password পরিবর্তন আছে।

## যা আছে
- মোবাইল/কম্পিউটার উপযোগী দোকানের পেজ
- ৬টি ক্যাটাগরি: পাঞ্জাবি, গেঞ্জি ও টি-শার্ট, জুয়েলারি, কসমেটিক্স, গিফট আইটেম, ফুড আইটেম
- শপিং ব্যাগ, ডেলিভারি তথ্য ও অর্ডার জমা
- Cash on Delivery, bKash, Nagad-এর ম্যানুয়াল পেমেন্ট তথ্য
- `/admin` থেকে Admin Login
- পণ্য যোগ/সম্পাদনা/মুছে ফেলা, ছবি আপলোড, স্টক নিয়ন্ত্রণ
- অর্ডার দেখা ও স্ট্যাটাস পরিবর্তন
- WhatsApp/bKash/Nagad নম্বর ও দোকানের পরিচিতি সেট করা
- Admin password পরিবর্তন

## জরুরি সীমাবদ্ধতা
- bKash/Nagad এখানে ম্যানুয়াল পেমেন্ট পদ্ধতি: গ্রাহক নম্বর ও Transaction ID দিতে পারে; টাকা স্বয়ংক্রিয়ভাবে গ্রহণ/যাচাই হয় না। এর জন্য অনুমোদিত merchant account ও payment gateway/API integration আলাদাভাবে করতে হবে।
- কুরিয়ার বুকিং, SMS, ইমেইল নোটিফিকেশন, রিটার্ন/রিফান্ড workflow, কুপন, analytics এবং multi-admin এখনো সংযুক্ত নয়।
- SQLite ফাইল `data/nayr.sqlite`-এ থাকে। Hosting-এ persistent disk/volume ছাড়া redeploy হলে ডেটা হারাতে পারে। ব্যাকআপ রাখুন।
- বাস্তবে প্রকাশের আগে privacy policy, terms, delivery/return policy, SSL/HTTPS, database backup এবং adult/trusted technical support দিয়ে security review করান।
- নমুনা পণ্য/দাম পরিবর্তন করে আসল তথ্য দিন।

## কম্পিউটারে চালু করা
1. Node.js 20 বা তার পরের LTS সংস্করণ ইনস্টল করুন।
2. এই ফোল্ডারে Terminal খুলুন।
3. `.env.example` কপি করে `.env` নাম দিন।
4. `.env`-এ `ADMIN_PASSWORD` বদলে শক্তিশালী ও আলাদা পাসওয়ার্ড দিন। `SESSION_SECRET`-এ দীর্ঘ random secret দিন।
5. চালান:
   ```bash
   npm install
   npm start
   ```
6. ব্রাউজারে `http://localhost:3000` খুলুন।
7. Admin: `http://localhost:3000/admin`। Username হবে `.env`-এর `ADMIN_USERNAME` (ডিফল্ট `admin`)।

## মোবাইলে কীভাবে ব্যবহার করবেন
### শুধু ক্রেতা হিসেবে
লাইভ ওয়েবসাইটের URL Chrome-এ খুললেই কেনাকাটা করা যাবে। Chrome menu → “Add to Home screen” দিলে ফোনের হোমস্ক্রিনে শর্টকাট হবে।

### Admin হিসেবে
লাইভ ওয়েবসাইটের URL-এর শেষে `/admin` লিখে খুলুন। নিজের Admin username/password দিয়ে প্রবেশ করুন। পণ্য, স্টক, ছবি, অর্ডার, নম্বর ও শপের তথ্য মোবাইল থেকেই বদলানো যাবে। পাসওয়ার্ড কাউকে দেবেন না।

### ফোন থেকেই সাইট চালু/পরীক্ষা
Android-এ Node.js পরিবেশ (যেমন Termux) ব্যবহার করা সম্ভব, তবে সেটআপ তুলনামূলক জটিল এবং ফোন বন্ধ/অ্যাপ বন্ধ হলে সার্ভার থেমে যেতে পারে। স্থায়ী অনলাইন দোকানের জন্য hosting-এ deploy করাই ভালো। প্রথমবার deploy করতে কম্পিউটার বা বিশ্বস্ত কারও সাহায্য লাগতে পারে।

## Hosting-এ প্রকাশের সাধারণ ধাপ
1. প্রজেক্টটি GitHub private repository-তে রাখুন; `.env`, `data/`, ব্যক্তিগত নম্বর বা পাসওয়ার্ড কখনো upload করবেন না।
2. Node.js app support করে এমন hosting provider-এ repository connect করুন।
3. Build command: `npm install`; Start command: `npm start`।
4. Environment variables হিসেবে `NODE_ENV=production`, `SESSION_SECRET`, `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `STORE_NAME` সেট করুন।
5. Persistent disk/volume attach করে সেটি `/app/data`-তে mount করুন (provider অনুযায়ী path বদলাতে পারে)। Upload folder-ও persistent storage-এ রাখুন বা object storage ব্যবহার করুন।
6. HTTPS/domain চালু করে mobile browser-এ পরীক্ষা করুন।
7. Admin password বদলান, নমুনা পণ্য সরিয়ে আসল পণ্য দিন, অর্ডার test করুন।

**গুরুত্বপূর্ণ:** Hosting provider-এর বর্তমান নির্দেশনা দেখে deploy করবেন। Free hosting-এ persistent storage নাও থাকতে পারে; সে ক্ষেত্রে অর্ডার/পণ্য মুছে যেতে পারে। bKash/Nagad payment gateway চালুর জন্য সংশ্লিষ্ট প্রতিষ্ঠানের অনুমোদন প্রয়োজন।
